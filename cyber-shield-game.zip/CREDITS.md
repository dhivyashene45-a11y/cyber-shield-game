# Picture credits

Real photos were resized. AI pictures were cropped from sample sheets and resized.

- `images/01.jpg` (REAL): Photo: Stefan van der Walt, CC0 (scikit-image sample data)
- `images/02.jpg` (AI): AI sample published by Stability AI (generative-models project)
- `images/03.jpg` (REAL): Photo: danielbuechele, CC BY 2.0 (via scikit-learn)
- `images/04.jpg` (AI): AI sample published by Stability AI (generative-models project)
- `images/05.jpg` (REAL): Photo: Rachel Michetti, courtesy of Pikolo Espresso Bar, CC0 (scikit-image sample data)
- `images/06.jpg` (AI): AI sample published in the CompVis Stable Diffusion project
- `images/07.jpg` (AI): AI sample published by Stability AI (generative-models project)
- `images/08.jpg` (REAL): Photo: SpaceX, public domain (scikit-image sample data)
- `images/09.jpg` (AI): AI sample published in the CompVis Stable Diffusion project
- `images/10.jpg` (REAL): Photo: vultilion, CC BY 2.0 (via scikit-learn)
- `images/11.jpg` (AI): AI sample published by Stability AI (generative-models project)
- `images/12.jpg` (REAL): Photo: Lav Varshney, CC0 (scikit-image sample data)
- `images/13.jpg` (AI): AI sample published by Stability AI (generative-models project)
- `images/14.jpg` (REAL): Image: NASA Hubble telescope, public domain (scikit-image sample data). A processed telescope image.
- `images/15.jpg` (AI): AI sample published by Stability AI (generative-models project)

## Sources
- https://github.com/Stability-AI/generative-models (assets/000.jpg, assets/turbo_tile.png)
- https://github.com/CompVis/stable-diffusion (assets/stable-samples/txt2img)
- https://github.com/scikit-image/scikit-image
- https://github.com/scikit-learn/scikit-learn
- CC BY 2.0: https://creativecommons.org/licenses/by/2.0/
- china.jpg original: https://www.flickr.com/photos/danielbuechele/6061409035/
- flower.jpg original: https://www.flickr.com/photos/vultilion/6056698931/

The licences of the two AI model projects do not specifically mention their sample pictures.
