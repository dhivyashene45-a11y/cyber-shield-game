# Cyber Shield: AI & Online Safety Game

A facilitator-led team game for participants aged 10–13. It has five activities, a pledge, timers and a scoreboard.

## Launch on GitHub Pages
1. Sign in to github.com and create a new **public** repository, for example `cyber-shield-game`.
2. Choose **Add file → Upload files**, drag in `index.html`, `README.md`, `CREDITS.md` and the whole `images` folder, then **Commit changes**. Keep the name `index.html`.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, set Source to **Deploy from a branch**, Branch to **main** and folder to **/(root)**. Click **Save**.
5. Wait a few minutes. Your link will be `https://YOUR-USERNAME.github.io/cyber-shield-game/`.

## "AI or Real?" pictures
15 pictures are built in: 7 real and 8 AI. Credits are in `CREDITS.md` and appear after each answer is revealed. At about 45 seconds each, all 15 fit in 12 minutes.

To change one, replace its file in `images` and edit its line under `let PICTURES = [` in `index.html`. `answer` must be exactly `"AI"` or `"REAL"`. Update `CREDITS.md` too.

## Running the event
- Use one facilitator device connected to the projector.
- Set team names (2–8) under **Scores** before starting.
- Press **Reset scores** before each new session.
- Scores stay in that browser only. There is no shared live leaderboard.

## Scoring
| Activity | Points |
|---|---|
| AI or Real? | 1 per correct vote (automatic) |
| Traffic Light | 1 per correct team |
| Password Master | Classification 1, explanation 2, creative password 3 |
| Stranger Danger | 1 per correct team, plus 1 red flag bonus |
| Escape Challenge | 1 per puzzle, plus 2 for unlocking in time |

Each award button works once per question per team. In Password Master rounds 1 and 2, that means once per round. Use the +1 / −1 buttons under Scores for anything extra.
